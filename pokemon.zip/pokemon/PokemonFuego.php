<?php
require_once "Pokemon.php";

class PokemonFuego extends Pokemon {

    public function __construct($nombre, $tipo, $ataque, $poderAtaque){
        parent::__construct($nombre, "Fuego", $tipo, $ataque, $poderAtaque);
    }

    public function atacar(){
        $danioTotal = $this->poderAtaque + 10;
        return $this->nombre . " usa " . $this->ataque . 
               " con fuerza de fuego y causa " . $danioTotal . " de daño.";
    }
}
?>