<?php
class Pokemon {
    protected $nombre;
    protected $elemento;
    protected $ataque;
    protected $poderAtaque;
    protected $nivel;
    protected $vida;

    // Constructor ajustado a 4 parámetros principales
    public function __construct($nombre, $elemento, $ataque, $poderAtaque){
        $this->nombre = $nombre;
        $this->elemento = $elemento;
        $this->ataque = $ataque;
        $this->poderAtaque = $poderAtaque;
        $this->nivel = 1;
        $this->vida = 100;
    }

    public function getNombre() { return $this->nombre; }
    public function getElemento() { return $this->elemento; }
    public function getPoderAtaque() { return $this->poderAtaque; }
    public function getVida() { return $this->vida; }

    // Método para el combate (usado en fight.php)
    public function getDanio() {
        return $this->poderAtaque;
    }

    // Método para recibir daño (usado en fight.php)
    public function restaVida($danio) {
        $this->vida -= $danio;
        if ($this->vida < 0) $this->vida = 0;
    }

    public function atacar(){
        return $this->nombre . " usa " . $this->ataque . " y causa " . $this->poderAtaque . " de daño.";
    }

    public function evolucionar(){
        $this->nivel++;
        $this->vida += 20;
        return $this->nombre . " ha evolucionado al nivel " . $this->nivel . " y ahora tiene " . $this->vida . " puntos de vida.";
    }

    public function mostrarInfo(){
        return "
        <article style='border: 1px solid #ccc; margin: 10px; padding: 10px; border-radius: 8px; background: #fff;'>
            <h3>" . $this->nombre . " (" . $this->elemento . ")</h3>
            <p><strong>Ataque:</strong> " . $this->ataque . " | <strong>Poder:</strong> " . $this->poderAtaque . "</p>
            <p><strong>Nivel:</strong> " . $this->nivel . " | <strong>Vida:</strong> " . $this->vida . "</p>
        </article>";
    }
}
?>