<?php
require_once "Pokemon.php";

class PokemonPlanta extends Pokemon {

    public function __construct($nombre, $tipo, $ataque, $poderAtaque){
        parent::__construct($nombre, "Planta", $tipo, $ataque, $poderAtaque);
        $this->vida = 120;
    }

    public function mostrarInfo(){
        return parent::mostrarInfo() . "<p>Clase especial: Pokémon de planta</p>";
    }
}
?>