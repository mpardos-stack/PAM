<?php
require_once "Pokemon.php";
require_once "Entrenadora.php";
session_start();

if (!isset($_SESSION["pokemons"])) {
    $_SESSION["pokemons"] = [];
}

if (!isset($_SESSION["entrenadoras"])) {
    $_SESSION["entrenadoras"] = [];
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="estilos.css">
    <title>Fight Entrenadora</title>
</head>
<body>
    <h1>Fight Entrenadora</h1>

    <form method="POST" action="">
        <section>
            <h3>Selecciona primero Entrenadora</h3>
            <select name="entre1">
               <?php
                foreach ($_SESSION["entrenadoras"] as $identrenadoras => $entrenadora) {
                    echo "<option value='$identrenadoras'>" . $entrenadora->MostrarInfo() . "</option>";
                }
                ?>
            </select>
        </section>

        <section>
            <h3>Selecciona segundo Entrenadora</h3>
            <select name="entre2">
                <?php
                foreach ($_SESSION["entrenadoras"] as $identrenadoras => $entrenadora) {
                    echo "<option value='$identrenadoras'>" . $entrenadora->MostrarInfo() . "</option>";
                }
                ?>
            </select>
            <p>
        <button type="submit">Enviar</button>
        </p>
        </section>

    </form>

    <section>
    <?php
    if(isset($_POST['entre1'],$_POST['entre2'])){
        $n_entrenadora1=$_POST['entre1'];
        $n_entrenadora2=$_POST['entre2'];
        $entrenadora1=$_SESSION['entrenadoras'][$n_entrenadora1];
        $entrenadora2=$_SESSION['entrenadoras'][$n_entrenadora2];
        if($entrenadora1 != $entrenadora2){
            
            echo "<form method='POST' action=''>
            <section class='pokemon'>
            <h3>Selecciona pokemon de ".$entrenadora1->MostrarInfo()."</h3>
                <select name='pokemon1'>";

            foreach ($_SESSION["pokemons"] as $idpokemon => $pokemon) {
                    echo "<option value='$idpokemon'>" . $pokemon->getNombre() . "</option>";
                }

            echo"</select>
            </section>

            <section class='pokemon'>
            <h3>Selecciona pokemon de ".$entrenadora2->MostrarInfo()."</h3>
                <select name='pokemon2'>";

            foreach ($_SESSION["pokemons"] as $idpokemon => $pokemon) {
                    echo "<option value='$idpokemon'>" . $pokemon->getNombre() . "</option>";
                }

            echo "</select>
            <p>
                <button type='submit'>Enviar</button>
            </p>
            </section>
            </form>";
        }else{
            echo "<script>alert('No puedes elegir dos entrenadora mismo')</script>";
        }
    }

    if(isset($_POST['pokemon1'],$_POST['pokemon2'])){
        $n_pokemon1=$_POST['pokemon1'];
        $n_pokemon2=$_POST['pokemon2'];
        $pokemon1=$_SESSION['pokemons'][$n_pokemon1];
        $pokemon2=$_SESSION['pokemons'][$n_pokemon2];
        $ataque_vida1=$pokemon1->getPoderAtaque();
        $vida_pokemon1=$pokemon1->getVida();
        $ataque_vida2=$pokemon2->getPoderAtaque();
        $vida_pokemon2=$pokemon2->getVida();
        //start
        if($pokemon1 -> getVida() > 0 && $pokemon2 -> getVida() > 0){
        $pokemon1->recibirDanio($ataque_vida2);
        $pokemon2->recibirDanio($ataque_vida1);
        echo "<p>Pokemon 1 queda " . $pokemon1->getVida() . "</p>"; 
        echo "<p>Pokemon 2 queda " . $pokemon2->getVida() . "</p>";
        }else{
            if($pokemon1->getVida() > $pokemon2->getVida()){
                echo "pokemon1 ganado";
            }elseif($pokemon1->getVida()==$pokemon2->getVida()){
                echo "no hay pokemon gana, todos 0";
            }else{
                echo "pokemon2 ganado";
            }
        }
    }

    
    ?>

    <a href="crearpokemon.php">Crear Pokemon</a>
    <a href="crearentrenadora.php">Crear Entrenadora</a>
</section>
</body>
</html>