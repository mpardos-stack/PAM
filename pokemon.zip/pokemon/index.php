<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Menú Principal Pokémon</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body class="fondoprincipal">

    <audio src="audio/Pokemon SilverGoldCrystal - National Park.mp3" autoplay loop></audio>

    <header class="contenedor-principal">
        <h1 class="titulo">Centro de Control</h1>
        
        <nav class="menu-navegacion">
            <small>¿Qué quieres hacer?</small>
            
            <ul class="lista-items">
                <li class="item-lista"><a href="crearpokemon.php" class="enlace-navegacion"> Crear Pokémon</a></li>
                <li class="item-lista"><a href="crearentrenadora.php" class="enlace-navegacion">Crear Entrenador/a</a></li>
                <li class="item-lista"><a href="gestion.php" class="enlace-navegacion">PC de Bill</a></li>
            </ul>
        </nav>
    </header>

</body>
</html>