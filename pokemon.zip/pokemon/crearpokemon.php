<?php
// IMPORTANTE: Cargar todas las clases antes de session_start
require_once 'Pokemon.php';
require_once 'PokemonFuego.php';
require_once 'PokemonAgua.php';
require_once 'PokemonPlanta.php';

session_start();

if (!isset($_SESSION["pokemons"])) $_SESSION["pokemons"] = [];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["nombre"])) {
    $nombre = $_POST["nombre"];
    $elemento = $_POST["elemento"];
    $ataqueNombre = !empty($_POST["m1"]) ? $_POST["m1"] : "Placaje";
    
    // Recogemos el poder del ataque desde el campo 'at' del formulario
    $poderAtaque = isset($_POST["at"]) ? (int)$_POST["at"] : 50; 
    // Recogemos la vida inicial desde el campo 'hp'
    $vidaInicial = isset($_POST["hp"]) ? (int)$_POST["hp"] : 100;

    // Instanciamos según el elemento seleccionado
    switch ($elemento) {
        case 'Fuego':
            // Estas clases suelen recibir (nombre, tipo/elemento, ataque, poder)
            $nuevo = new PokemonFuego($nombre, "Fuego", $ataqueNombre, $poderAtaque);
            break;
        case 'Agua':
            $nuevo = new PokemonAgua($nombre, "Agua", $ataqueNombre, $poderAtaque);
            break;
        case 'Planta':
            $nuevo = new PokemonPlanta($nombre, "Planta", $ataqueNombre, $poderAtaque);
            break;
        default:
            $nuevo = new Pokemon($nombre, $elemento, $ataqueNombre, $poderAtaque);
            break;
    }
    
    // Guardamos en la sesión
    $_SESSION["pokemons"][] = $nuevo;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Pokémon</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body class="fondo1">
    <main class="contenedor-principal">
        <section class="formulario">
            <h1 class="titulo">Laboratorio Pokémon</h1>
            <a href="index.php" class="boton-volver">VOLVER</a>
            <form method="POST">
                <label class="etiqueta">Nombre: <input type="text" name="nombre" class="campo-entrada" required></label>
                
                <label class="etiqueta">Elemento: 
                    <select name="elemento" class="campo-entrada">
                        <option value="Fuego">Fuego</option>
                        <option value="Agua">Agua</option>
                        <option value="Planta">Planta</option>
                        <option value="Normal">Normal</option>
                    </select>
                </label>

                <fieldset class="grupo-campos">
                    <legend class="leyenda-campos">Estadísticas Base</legend>
                    <label class="etiqueta">HP: <input type="number" name="hp" value="100" class="campo-entrada"></label>
                    <label class="etiqueta">ATK: <input type="number" name="at" value="50" class="campo-entrada"></label>
                    <label class="etiqueta">DEF: <input type="number" name="def" value="50" class="campo-entrada"></label>
                    <label class="etiqueta">SP.ATK: <input type="number" name="at_esp" value="50" class="campo-entrada"></label>
                    <label class="etiqueta">SP.DEF: <input type="number" name="def_esp" value="50" class="campo-entrada"></label>
                    <label class="etiqueta">VEL: <input type="number" name="vel" value="50" class="campo-entrada"></label>
                </fieldset>

                <fieldset class="grupo-campos">
                    <legend class="leyenda-campos">Movimientos (Máx 4)</legend>
                    <input type="text" name="m1" placeholder="Movimiento 1" class="campo-entrada">
                    <input type="text" name="m2" placeholder="Movimiento 2" class="campo-entrada">
                    <input type="text" name="m3" placeholder="Movimiento 3" class="campo-entrada">
                    <input type="text" name="m4" placeholder="Movimiento 4" class="campo-entrada">
                </fieldset>

                <button type="submit" class="btn-accion">Crear Pokémon</button>
            </form>
        </section>

        <section class="lista">
            <h2 class="titulo">Pokédex Actual</h2>
            <?php 
            if(isset($_SESSION["pokemons"]) && count($_SESSION["pokemons"]) > 0){
                foreach ($_SESSION["pokemons"] as $p) {
                    // Verificamos que sea un objeto válido antes de llamar al método
                    if (is_object($p) && method_exists($p, 'mostrarInfo')) {
                        echo $p->mostrarInfo(); 
                    }
                }
            } else {
                echo "<p>No hay Pokémon creados.</p>";
            }
            ?>
        </section>

        <nav class="menu-navegacion">
            <a href="index.php">Volver al Inicio</a>
        </nav>
    </main>
</body>
</html>