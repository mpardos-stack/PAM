<?php
require_once "Pokemon.php";

class PokemonAgua extends Pokemon {

    public function __construct($nombre, $tipo, $ataque, $poderAtaque){
        parent::__construct($nombre, "Agua", $tipo, $ataque, $poderAtaque);
    }

    public function evolucionar(){
        $this->nivel++;
        $this->vida += 30;
        return $this->nombre . " ha evolucionado al nivel " . $this->nivel . 
               " y ahora tiene " . $this->vida . " puntos de vida.";
    }
}
?>